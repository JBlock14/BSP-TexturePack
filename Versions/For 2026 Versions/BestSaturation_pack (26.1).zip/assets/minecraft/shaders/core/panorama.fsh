#version 330

uniform samplerCube Sampler0;

in vec3 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);

    // --- Duplicar saturación ---
    float luma = dot(color.rgb, vec3(0.299, 0.587, 0.114)); // luminancia perceptual
    vec3 gray = vec3(luma);
    color.rgb = mix(gray, color.rgb, 2.0); // factor 2.0 duplica la saturación

    fragColor = color;
}
