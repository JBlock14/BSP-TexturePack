#version 330

#moj_import <minecraft:fog.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
flat in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;

    // --- Duplicar saturación ---
    float luma = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    vec3 gray = vec3(luma);
    color.rgb = mix(gray, color.rgb, 2.0); // factor 2.0 duplica la saturación

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance,
                          FogEnvironmentalStart, FogEnvironmentalEnd,
                          FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
