#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

out vec4 fragColor;

void main() {
    vec4 color = ColorModulator;

    // --- Duplicar saturación ---
    float luma = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    vec3 gray = vec3(luma);
    color.rgb = mix(gray, color.rgb, 2.0); // factor 2.0 duplica la saturación

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance,
                          0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
